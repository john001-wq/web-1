import type { Express } from "express";
import express from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertPortfolioItemSchema, insertContactSchema, insertAdminProfileSchema } from "@shared/schema";
import { setupAuth, isAuthenticated } from "./replitAuth";
import multer from "multer";
import path from "path";
import fs from "fs";

// Configure multer for file uploads
const uploadDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const upload = multer({
  storage: multer.diskStorage({
    destination: uploadDir,
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
      cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    }
  }),
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|gif/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Only image files are allowed!'));
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Serve uploaded files
  app.use('/uploads', (req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    next();
  }, express.static(uploadDir));

  // Portfolio routes
  app.get('/api/portfolio', async (req, res) => {
    try {
      const items = await storage.getPortfolioItems();
      res.json(items);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch portfolio items' });
    }
  });

  app.get('/api/portfolio/:id', async (req, res) => {
    try {
      const item = await storage.getPortfolioItem(req.params.id);
      if (!item) {
        return res.status(404).json({ message: 'Portfolio item not found' });
      }
      res.json(item);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch portfolio item' });
    }
  });

  app.post('/api/portfolio', isAuthenticated, upload.single('image'), async (req, res) => {
    try {
      const data = {
        ...req.body,
        tags: req.body.tags ? req.body.tags.split(',').map((tag: string) => tag.trim()) : [],
      };

      if (req.file) {
        data.imageUrl = `/uploads/${req.file.filename}`;
      }

      const validatedData = insertPortfolioItemSchema.parse(data);
      const item = await storage.createPortfolioItem(validatedData);
      res.status(201).json(item);
    } catch (error) {
      if (req.file) {
        // Clean up uploaded file if validation fails
        fs.unlink(path.join(uploadDir, req.file.filename), () => {});
      }
      
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(500).json({ message: 'Failed to create portfolio item' });
      }
    }
  });

  app.put('/api/portfolio/:id', isAuthenticated, upload.single('image'), async (req, res) => {
    try {
      const data = {
        ...req.body,
        tags: req.body.tags ? req.body.tags.split(',').map((tag: string) => tag.trim()) : undefined,
      };

      if (req.file) {
        data.imageUrl = `/uploads/${req.file.filename}`;
      }

      const validatedData = insertPortfolioItemSchema.partial().parse(data);
      const item = await storage.updatePortfolioItem(req.params.id, validatedData);
      
      if (!item) {
        return res.status(404).json({ message: 'Portfolio item not found' });
      }
      
      res.json(item);
    } catch (error) {
      if (req.file) {
        fs.unlink(path.join(uploadDir, req.file.filename), () => {});
      }
      
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(500).json({ message: 'Failed to update portfolio item' });
      }
    }
  });

  app.delete('/api/portfolio/:id', isAuthenticated, async (req, res) => {
    try {
      const item = await storage.getPortfolioItem(req.params.id);
      if (!item) {
        return res.status(404).json({ message: 'Portfolio item not found' });
      }

      // Delete associated image file
      if (item.imageUrl && item.imageUrl.startsWith('/uploads/')) {
        const filename = item.imageUrl.replace('/uploads/', '');
        const filePath = path.join(uploadDir, filename);
        fs.unlink(filePath, () => {});
      }

      const deleted = await storage.deletePortfolioItem(req.params.id);
      if (deleted) {
        res.json({ message: 'Portfolio item deleted successfully' });
      } else {
        res.status(404).json({ message: 'Portfolio item not found' });
      }
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete portfolio item' });
    }
  });

  // Contact form route
  app.post('/api/contact', async (req, res) => {
    try {
      const validatedData = insertContactSchema.parse(req.body);
      const contact = await storage.createContact(validatedData);
      
      // In a real application, you would send an email here using nodemailer
      // For now, we'll just log the contact and return success
      console.log('New contact form submission:', contact);
      
      res.status(201).json({ message: 'Contact form submitted successfully' });
    } catch (error) {
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(500).json({ message: 'Failed to submit contact form' });
      }
    }
  });

  // Admin profile routes
  app.get('/api/admin/profile', isAuthenticated, async (req, res) => {
    try {
      const profile = await storage.getAdminProfile();
      if (!profile) {
        return res.status(404).json({ message: 'Admin profile not found' });
      }
      res.json(profile);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch admin profile' });
    }
  });

  app.put('/api/admin/profile', isAuthenticated, upload.fields([
    { name: 'profileImage', maxCount: 1 },
    { name: 'heroImage', maxCount: 1 }
  ]), async (req, res) => {
    try {
      const data = { ...req.body };
      
      // Handle skills array
      if (data.skills) {
        data.skills = data.skills.split(',').map((skill: string) => skill.trim()).filter((skill: string) => skill);
      }
      
      // Handle social links array
      if (data.socialLinks) {
        data.socialLinks = data.socialLinks.split(',').map((link: string) => link.trim()).filter((link: string) => link);
      }

      // Handle uploaded files
      const files = req.files as { [fieldname: string]: Express.Multer.File[] };
      if (files?.profileImage?.[0]) {
        data.profileImage = `/uploads/${files.profileImage[0].filename}`;
      }
      if (files?.heroImage?.[0]) {
        data.heroImage = `/uploads/${files.heroImage[0].filename}`;
      }

      const validatedData = insertAdminProfileSchema.parse(data);
      const profile = await storage.createOrUpdateAdminProfile(validatedData);
      
      res.json(profile);
    } catch (error) {
      // Clean up uploaded files if validation fails
      const files = req.files as { [fieldname: string]: Express.Multer.File[] };
      if (files?.profileImage?.[0]) {
        fs.unlink(path.join(uploadDir, files.profileImage[0].filename), () => {});
      }
      if (files?.heroImage?.[0]) {
        fs.unlink(path.join(uploadDir, files.heroImage[0].filename), () => {});
      }
      
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(500).json({ message: 'Failed to update admin profile' });
      }
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
