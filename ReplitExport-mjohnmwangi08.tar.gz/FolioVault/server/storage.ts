import { type User, type InsertUser, type UpsertUser, type PortfolioItem, type InsertPortfolioItem, type Contact, type InsertContact, type AdminProfile, type InsertAdminProfile, users, portfolioItems, contacts, adminProfile } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  getPortfolioItems(): Promise<PortfolioItem[]>;
  getPortfolioItem(id: string): Promise<PortfolioItem | undefined>;
  createPortfolioItem(item: InsertPortfolioItem): Promise<PortfolioItem>;
  updatePortfolioItem(id: string, item: Partial<InsertPortfolioItem>): Promise<PortfolioItem | undefined>;
  deletePortfolioItem(id: string): Promise<boolean>;
  
  createContact(contact: InsertContact): Promise<Contact>;
  getContacts(): Promise<Contact[]>;
  
  getAdminProfile(): Promise<AdminProfile | undefined>;
  createOrUpdateAdminProfile(profile: InsertAdminProfile): Promise<AdminProfile>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private portfolioItems: Map<string, PortfolioItem>;
  private contacts: Map<string, Contact>;
  private adminProfile?: AdminProfile;

  constructor() {
    this.users = new Map();
    this.portfolioItems = new Map();
    this.contacts = new Map();
    
    // Add some initial portfolio items and admin profile
    this.seedPortfolioItems();
    this.seedAdminProfile();
  }

  private seedPortfolioItems() {
    const items: InsertPortfolioItem[] = [
      {
        title: "E-commerce Platform",
        description: "Full-stack e-commerce solution with admin dashboard, payment integration, and inventory management.",
        category: "Web App",
        imageUrl: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
        tags: ["React", "Node.js", "MongoDB"],
      },
      {
        title: "Fitness Tracker App",
        description: "React Native mobile application for fitness tracking with social features and goal setting.",
        category: "Mobile",
        imageUrl: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
        tags: ["React Native", "Firebase", "UI/UX"],
      },
      {
        title: "Brand Identity System",
        description: "Complete brand identity design including logo, color palette, typography, and brand guidelines.",
        category: "Design",
        imageUrl: "https://images.unsplash.com/photo-1558655146-9f40138edfeb?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
        tags: ["Figma", "Illustrator", "Branding"],
      },
    ];

    items.forEach(item => {
      const id = randomUUID();
      const portfolioItem: PortfolioItem = {
        ...item,
        id,
        imageUrl: item.imageUrl || null,
        projectUrl: item.projectUrl || null,
        tags: item.tags || null,
        createdAt: new Date(),
      };
      this.portfolioItems.set(id, portfolioItem);
    });
  }

  private seedAdminProfile() {
    const profile: AdminProfile = {
      id: randomUUID(),
      firstName: "Alex",
      lastName: "Johnson",
      title: "Creative Professional",
      bio: "Passionate about creating meaningful digital experiences through thoughtful design and innovative development. With over 5 years of experience in web development and design, I've had the privilege of working with diverse clients ranging from startups to established enterprises.",
      email: "alex.johnson@example.com",
      phone: "+1 (555) 123-4567",
      location: "San Francisco, CA",
      profileImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=400",
      heroImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=400",
      skills: ["React", "Node.js", "TypeScript", "UI/UX Design", "MongoDB", "Figma", "AWS", "Docker"],
      socialLinks: ["https://linkedin.com/in/alexjohnson", "https://github.com/alexjohnson", "https://twitter.com/alexjohnson"],
      updatedAt: new Date(),
    };
    this.adminProfile = profile;
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      id,
      email: insertUser.email || null,
      firstName: insertUser.firstName || null,
      lastName: insertUser.lastName || null,
      profileImageUrl: insertUser.profileImageUrl || null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const existingUser = userData.id ? this.users.get(userData.id) : undefined;
    
    if (existingUser) {
      const updatedUser: User = {
        ...existingUser,
        ...userData,
        updatedAt: new Date(),
      };
      this.users.set(updatedUser.id, updatedUser);
      return updatedUser;
    } else {
      const id = userData.id || randomUUID();
      const newUser: User = {
        id,
        email: userData.email || null,
        firstName: userData.firstName || null,
        lastName: userData.lastName || null,
        profileImageUrl: userData.profileImageUrl || null,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      this.users.set(id, newUser);
      return newUser;
    }
  }

  async getPortfolioItems(): Promise<PortfolioItem[]> {
    return Array.from(this.portfolioItems.values()).sort(
      (a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()
    );
  }

  async getPortfolioItem(id: string): Promise<PortfolioItem | undefined> {
    return this.portfolioItems.get(id);
  }

  async createPortfolioItem(item: InsertPortfolioItem): Promise<PortfolioItem> {
    const id = randomUUID();
    const portfolioItem: PortfolioItem = {
      ...item,
      id,
      imageUrl: item.imageUrl || null,
      projectUrl: item.projectUrl || null,
      tags: item.tags || null,
      createdAt: new Date(),
    };
    this.portfolioItems.set(id, portfolioItem);
    return portfolioItem;
  }

  async updatePortfolioItem(id: string, item: Partial<InsertPortfolioItem>): Promise<PortfolioItem | undefined> {
    const existing = this.portfolioItems.get(id);
    if (!existing) return undefined;
    
    const updated: PortfolioItem = { ...existing, ...item };
    this.portfolioItems.set(id, updated);
    return updated;
  }

  async deletePortfolioItem(id: string): Promise<boolean> {
    return this.portfolioItems.delete(id);
  }

  async createContact(contact: InsertContact): Promise<Contact> {
    const id = randomUUID();
    const contactRecord: Contact = {
      ...contact,
      id,
      createdAt: new Date(),
    };
    this.contacts.set(id, contactRecord);
    return contactRecord;
  }

  async getContacts(): Promise<Contact[]> {
    return Array.from(this.contacts.values()).sort(
      (a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()
    );
  }

  async getAdminProfile(): Promise<AdminProfile | undefined> {
    return this.adminProfile;
  }

  async createOrUpdateAdminProfile(profile: InsertAdminProfile): Promise<AdminProfile> {
    const id = this.adminProfile?.id || randomUUID();
    const adminProfile: AdminProfile = {
      ...profile,
      id,
      skills: profile.skills || null,
      socialLinks: profile.socialLinks || null,
      phone: profile.phone || null,
      location: profile.location || null,
      profileImage: profile.profileImage || null,
      heroImage: profile.heroImage || null,
      updatedAt: new Date(),
    };
    this.adminProfile = adminProfile;
    return adminProfile;
  }
}

export class DatabaseStorage implements IStorage {
  constructor() {
    // Initialize with sample data if database is empty
    this.initializeSampleData();
  }

  private async initializeSampleData() {
    try {
      // Check if portfolio items exist
      const existingItems = await db.select().from(portfolioItems).limit(1);
      
      if (existingItems.length === 0) {
        // Add sample portfolio items
        const sampleItems: InsertPortfolioItem[] = [
          {
            title: "E-commerce Platform",
            description: "Full-stack e-commerce solution with admin dashboard, payment integration, and inventory management.",
            category: "Web App",
            imageUrl: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
            tags: ["React", "Node.js", "MongoDB"],
          },
          {
            title: "Fitness Tracker App",
            description: "React Native mobile application for fitness tracking with social features and goal setting.",
            category: "Mobile",
            imageUrl: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
            tags: ["React Native", "Firebase", "UI/UX"],
          },
          {
            title: "Brand Identity System",
            description: "Complete brand identity design including logo, color palette, typography, and brand guidelines.",
            category: "Design",
            imageUrl: "https://images.unsplash.com/photo-1558655146-9f40138edfeb?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
            tags: ["Figma", "Illustrator", "Branding"],
          },
        ];

        await db.insert(portfolioItems).values(sampleItems);
      }
    } catch (error) {
      console.error('Error initializing sample data:', error);
    }
  }

  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async getPortfolioItems(): Promise<PortfolioItem[]> {
    const items = await db.select().from(portfolioItems).orderBy(portfolioItems.createdAt);
    return items.reverse(); // Most recent first
  }

  async getPortfolioItem(id: string): Promise<PortfolioItem | undefined> {
    const [item] = await db.select().from(portfolioItems).where(eq(portfolioItems.id, id));
    return item || undefined;
  }

  async createPortfolioItem(item: InsertPortfolioItem): Promise<PortfolioItem> {
    const [portfolioItem] = await db
      .insert(portfolioItems)
      .values(item)
      .returning();
    return portfolioItem;
  }

  async updatePortfolioItem(id: string, item: Partial<InsertPortfolioItem>): Promise<PortfolioItem | undefined> {
    const [updated] = await db
      .update(portfolioItems)
      .set(item)
      .where(eq(portfolioItems.id, id))
      .returning();
    return updated || undefined;
  }

  async deletePortfolioItem(id: string): Promise<boolean> {
    const result = await db.delete(portfolioItems).where(eq(portfolioItems.id, id));
    return (result.rowCount || 0) > 0;
  }

  async createContact(contact: InsertContact): Promise<Contact> {
    const [contactRecord] = await db
      .insert(contacts)
      .values(contact)
      .returning();
    return contactRecord;
  }

  async getContacts(): Promise<Contact[]> {
    const contactList = await db.select().from(contacts).orderBy(contacts.createdAt);
    return contactList.reverse(); // Most recent first
  }

  async getAdminProfile(): Promise<AdminProfile | undefined> {
    const [profile] = await db.select().from(adminProfile).limit(1);
    
    // If no profile exists, create a default one
    if (!profile) {
      const defaultProfile: InsertAdminProfile = {
        firstName: "Alex",
        lastName: "Johnson",
        title: "Creative Professional",
        bio: "Passionate about creating meaningful digital experiences through thoughtful design and innovative development. With over 5 years of experience in web development and design, I've had the privilege of working with diverse clients ranging from startups to established enterprises.",
        email: "alex.johnson@example.com",
        phone: "+1 (555) 123-4567",
        location: "San Francisco, CA",
        profileImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=400",
        heroImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=400",
        skills: ["React", "Node.js", "TypeScript", "UI/UX Design", "MongoDB", "Figma", "AWS", "Docker"],
        socialLinks: ["https://linkedin.com/in/alexjohnson", "https://github.com/alexjohnson", "https://twitter.com/alexjohnson"],
      };
      
      return await this.createOrUpdateAdminProfile(defaultProfile);
    }
    
    return profile;
  }

  async createOrUpdateAdminProfile(profile: InsertAdminProfile): Promise<AdminProfile> {
    // Check if profile exists
    const [existingProfile] = await db.select().from(adminProfile).limit(1);
    
    if (existingProfile) {
      // Update existing profile
      const [updated] = await db
        .update(adminProfile)
        .set({
          ...profile,
          updatedAt: new Date(),
        })
        .where(eq(adminProfile.id, existingProfile.id))
        .returning();
      return updated;
    } else {
      // Create new profile
      const [created] = await db
        .insert(adminProfile)
        .values({
          ...profile,
          updatedAt: new Date(),
        })
        .returning();
      return created;
    }
  }
}

// Use DatabaseStorage by default, fallback to MemStorage for development if needed
export const storage = new DatabaseStorage();
