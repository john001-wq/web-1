export default function ExperienceSection() {
  const experiences = [
    {
      period: "2022 - Present",
      title: "Senior Full Stack Developer",
      company: "TechCorp Solutions",
      description: "Leading development of enterprise web applications using React, Node.js, and cloud technologies. Mentoring junior developers and architecting scalable solutions.",
      color: "primary"
    },
    {
      period: "2020 - 2022",
      title: "Frontend Developer",
      company: "Digital Agency Pro",
      description: "Developed responsive web applications and collaborated with design teams to create engaging user experiences. Specialized in React and modern CSS frameworks.",
      color: "accent"
    },
    {
      period: "2019 - 2020",
      title: "Junior Web Developer",
      company: "StartupTech Inc",
      description: "Started my professional journey building web applications and learning best practices in agile development environment.",
      color: "green-600"
    }
  ];

  return (
    <section id="experiences" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-secondary mb-4">Experience</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            A journey of continuous learning and impactful projects across various industries.
          </p>
        </div>

        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-4 md:left-1/2 transform md:-translate-x-px h-full w-0.5 bg-gray-200"></div>
          
          <div className="space-y-12">
            {experiences.map((experience, index) => (
              <div key={index} className="relative flex items-center md:justify-between">
                <div className={`flex items-center ${index % 2 === 0 ? 'md:w-5/12 md:text-right' : 'md:w-5/12 md:ml-auto'}`}>
                  <div className="bg-white rounded-xl shadow-md p-6 ml-12 md:ml-0">
                    <div className={`flex items-center mb-3 ${index % 2 === 0 ? 'md:justify-end' : ''}`}>
                      <span className={`bg-${experience.color}/10 text-${experience.color} px-3 py-1 rounded-full text-sm font-medium`}>
                        {experience.period}
                      </span>
                    </div>
                    <h3 className="text-xl font-semibold text-secondary mb-2">{experience.title}</h3>
                    <p className={`text-${experience.color} font-medium mb-3`}>{experience.company}</p>
                    <p className="text-gray-600 text-sm">{experience.description}</p>
                  </div>
                </div>
                
                {/* Timeline dot */}
                <div className={`absolute left-2 md:left-1/2 transform md:-translate-x-1/2 w-4 h-4 bg-${experience.color} rounded-full border-4 border-white shadow-md`}></div>
                
                {index % 2 === 0 && <div className="hidden md:block w-5/12"></div>}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
