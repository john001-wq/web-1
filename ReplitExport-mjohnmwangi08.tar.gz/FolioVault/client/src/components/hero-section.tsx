import { Eye, Mail } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { AdminProfile } from "@shared/schema";

export default function HeroSection() {
  const { data: profile } = useQuery<AdminProfile>({
    queryKey: ['/api/admin/profile'],
  });

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const headerOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section id="home" className="pt-16 pb-20 bg-gradient-to-br from-gray-50 to-blue-50 min-h-screen flex items-center">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="animate-fade-in">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-secondary leading-tight mb-6">
              {profile?.firstName || "Creative"}
              <span className="text-primary block">{profile?.lastName || "Professional"}</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 leading-relaxed">
              {profile?.bio || "Crafting digital experiences that inspire and engage. Specializing in modern web development and creative design solutions."}
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <button 
                onClick={() => scrollToSection('portfolio')}
                className="bg-primary text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors duration-200 flex items-center justify-center"
              >
                <Eye className="w-5 h-5 mr-2" />
                View My Work
              </button>
              <button 
                onClick={() => scrollToSection('contact')}
                className="border-2 border-primary text-primary px-8 py-3 rounded-lg font-semibold hover:bg-primary hover:text-white transition-all duration-200 flex items-center justify-center"
              >
                <Mail className="w-5 h-5 mr-2" />
                Get In Touch
              </button>
            </div>
          </div>
          <div className="flex justify-center lg:justify-end animate-slide-up">
            <div className="relative">
              <div className="w-80 h-80 rounded-full bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                <div className="w-72 h-72 rounded-full bg-white shadow-xl flex items-center justify-center">
                  <img 
                    src={profile?.heroImage || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=400"} 
                    alt="Professional headshot" 
                    className="w-64 h-64 rounded-full object-cover"
                  />
                </div>
              </div>
              <div className="absolute -top-4 -right-4 w-12 h-12 bg-accent rounded-full opacity-80"></div>
              <div className="absolute -bottom-4 -left-4 w-8 h-8 bg-primary rounded-full opacity-60"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
