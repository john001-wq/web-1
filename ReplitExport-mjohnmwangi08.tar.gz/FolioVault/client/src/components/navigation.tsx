import { useState } from "react";
import { Menu, X, Settings } from "lucide-react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import type { AdminProfile } from "@shared/schema";

export default function Navigation() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  const { data: profile } = useQuery<AdminProfile>({
    queryKey: ['/api/admin/profile'],
  });

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const headerOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <nav className="bg-white shadow-sm fixed w-full top-0 z-50 border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex-shrink-0">
            <h1 className="text-xl font-bold text-secondary">
              {profile ? `${profile.firstName} ${profile.lastName}` : "Alex Johnson"}
            </h1>
          </div>
          
          {/* Desktop Navigation */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-8">
              <button 
                onClick={() => scrollToSection('home')} 
                className="text-secondary hover:text-primary transition-colors duration-200 font-medium"
              >
                Home
              </button>
              <button 
                onClick={() => scrollToSection('about')} 
                className="text-gray-600 hover:text-primary transition-colors duration-200 font-medium"
              >
                About
              </button>
              <button 
                onClick={() => scrollToSection('services')} 
                className="text-gray-600 hover:text-primary transition-colors duration-200 font-medium"
              >
                Services
              </button>
              <button 
                onClick={() => scrollToSection('experiences')} 
                className="text-gray-600 hover:text-primary transition-colors duration-200 font-medium"
              >
                Experience
              </button>
              <button 
                onClick={() => scrollToSection('portfolio')} 
                className="text-gray-600 hover:text-primary transition-colors duration-200 font-medium"
              >
                Portfolio
              </button>
              <button 
                onClick={() => scrollToSection('contact')} 
                className="text-gray-600 hover:text-primary transition-colors duration-200 font-medium"
              >
                Contact
              </button>
              <Link href="/admin">
                <button className="text-gray-600 hover:text-primary transition-colors duration-200 font-medium flex items-center">
                  <Settings className="w-4 h-4 mr-1" />
                  Admin
                </button>
              </Link>
            </div>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button 
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-gray-600 hover:text-primary focus:outline-none focus:text-primary"
            >
              {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-100">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <button 
              onClick={() => scrollToSection('home')} 
              className="block px-3 py-2 text-secondary hover:text-primary transition-colors duration-200 font-medium w-full text-left"
            >
              Home
            </button>
            <button 
              onClick={() => scrollToSection('about')} 
              className="block px-3 py-2 text-gray-600 hover:text-primary transition-colors duration-200 font-medium w-full text-left"
            >
              About
            </button>
            <button 
              onClick={() => scrollToSection('services')} 
              className="block px-3 py-2 text-gray-600 hover:text-primary transition-colors duration-200 font-medium w-full text-left"
            >
              Services
            </button>
            <button 
              onClick={() => scrollToSection('experiences')} 
              className="block px-3 py-2 text-gray-600 hover:text-primary transition-colors duration-200 font-medium w-full text-left"
            >
              Experience
            </button>
            <button 
              onClick={() => scrollToSection('portfolio')} 
              className="block px-3 py-2 text-gray-600 hover:text-primary transition-colors duration-200 font-medium w-full text-left"
            >
              Portfolio
            </button>
            <button 
              onClick={() => scrollToSection('contact')} 
              className="block px-3 py-2 text-gray-600 hover:text-primary transition-colors duration-200 font-medium w-full text-left"
            >
              Contact
            </button>
            <Link href="/admin">
              <button className="block px-3 py-2 text-gray-600 hover:text-primary transition-colors duration-200 font-medium w-full text-left flex items-center">
                <Settings className="w-4 h-4 mr-2" />
                Admin
              </button>
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
}
