import { Code, Palette, Rocket, Check } from "lucide-react";

export default function ServicesSection() {
  const services = [
    {
      icon: Code,
      iconColor: "text-primary",
      iconBgColor: "bg-primary/10",
      title: "Web Development",
      description: "Custom web applications built with modern technologies. Responsive, fast, and optimized for performance.",
      features: ["Frontend Development", "Backend API Development", "Database Design"]
    },
    {
      icon: Palette,
      iconColor: "text-accent",
      iconBgColor: "bg-accent/10",
      title: "UI/UX Design",
      description: "User-centered design solutions that enhance user experience and drive engagement.",
      features: ["User Research", "Wireframing & Prototyping", "Visual Design"]
    },
    {
      icon: Rocket,
      iconColor: "text-green-600",
      iconBgColor: "bg-green-100",
      title: "Consulting",
      description: "Strategic guidance for your digital transformation and technology stack decisions.",
      features: ["Technology Strategy", "Code Reviews", "Team Training"]
    }
  ];

  return (
    <section id="services" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-secondary mb-4">Services</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Comprehensive digital solutions tailored to your needs. From concept to deployment, I've got you covered.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const IconComponent = service.icon;
            return (
              <div key={index} className="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300 p-8">
                <div className={`w-12 h-12 ${service.iconBgColor} rounded-lg flex items-center justify-center mb-6`}>
                  <IconComponent className={`${service.iconColor} text-xl w-6 h-6`} />
                </div>
                <h3 className="text-xl font-semibold text-secondary mb-4">{service.title}</h3>
                <p className="text-gray-600 mb-6">{service.description}</p>
                <ul className="space-y-2 text-sm text-gray-600">
                  {service.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center">
                      <Check className={`${service.iconColor} mr-2 w-4 h-4`} />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
