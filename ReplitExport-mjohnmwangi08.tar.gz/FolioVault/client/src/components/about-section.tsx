import { Linkedin, Github, Twitter } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { AdminProfile } from "@shared/schema";

export default function AboutSection() {
  const { data: profile } = useQuery<AdminProfile>({
    queryKey: ['/api/admin/profile'],
  });
  
  const skills = profile?.skills || [
    "React", "Node.js", "TypeScript", "UI/UX Design", 
    "MongoDB", "Figma", "AWS", "Docker"
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-secondary mb-4">About Me</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Passionate about creating meaningful digital experiences through thoughtful design and innovative development.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <img 
              src="https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
              alt="Workspace setup with laptop and design tools" 
              className="rounded-xl shadow-lg w-full h-auto"
            />
          </div>
          <div>
            <h3 className="text-2xl font-semibold text-secondary mb-6">My Story</h3>
            <div className="space-y-4 text-gray-600">
              <p>
                {profile?.bio || "With over 5 years of experience in web development and design, I've had the privilege of working with diverse clients ranging from startups to established enterprises. My journey began with a fascination for how technology can solve real-world problems."}
              </p>
              <p>
                I specialize in creating user-centered digital solutions that not only look great but also deliver exceptional functionality. My approach combines creative thinking with technical expertise to bring ideas to life.
              </p>
            </div>

            <div className="mt-8">
              <h4 className="text-lg font-semibold text-secondary mb-4">Skills & Technologies</h4>
              <div className="flex flex-wrap gap-3">
                {skills.map((skill) => (
                  <span 
                    key={skill}
                    className="bg-gray-100 text-gray-700 px-3 py-2 rounded-full text-sm font-medium"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>

            <div className="mt-8 flex space-x-4">
              <a 
                href="#" 
                className="text-gray-600 hover:text-primary text-xl transition-colors duration-200"
                aria-label="LinkedIn"
              >
                <Linkedin />
              </a>
              <a 
                href="#" 
                className="text-gray-600 hover:text-primary text-xl transition-colors duration-200"
                aria-label="GitHub"
              >
                <Github />
              </a>
              <a 
                href="#" 
                className="text-gray-600 hover:text-primary text-xl transition-colors duration-200"
                aria-label="Twitter"
              >
                <Twitter />
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
