import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Save, Upload, Trash2, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { insertAdminProfileSchema, type AdminProfile } from "@shared/schema";
import { z } from "zod";

const adminFormSchema = insertAdminProfileSchema.extend({
  profileImageFile: z.any().optional(),
  heroImageFile: z.any().optional(),
});

type AdminFormData = z.infer<typeof adminFormSchema>;

export default function AdminPage() {
  const [profileImagePreview, setProfileImagePreview] = useState<string | null>(null);
  const [heroImagePreview, setHeroImagePreview] = useState<string | null>(null);
  const [profileImageFile, setProfileImageFile] = useState<File | null>(null);
  const [heroImageFile, setHeroImageFile] = useState<File | null>(null);
  const { toast } = useToast();
  const { isAuthenticated, isLoading: authLoading } = useAuth();

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Authentication Required",
        description: "You need to sign in to access the admin panel.",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 1000);
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  const { data: profile, isLoading } = useQuery<AdminProfile>({
    queryKey: ['/api/admin/profile'],
    enabled: isAuthenticated, // Only run query if authenticated
  });

  const form = useForm<AdminFormData>({
    resolver: zodResolver(adminFormSchema),
    defaultValues: {
      firstName: profile?.firstName || "",
      lastName: profile?.lastName || "",
      title: profile?.title || "",
      bio: profile?.bio || "",
      email: profile?.email || "",
      phone: profile?.phone || "",
      location: profile?.location || "",
      skills: profile?.skills || [],
      socialLinks: profile?.socialLinks || [],
    },
  });

  // Reset form when profile data loads
  useState(() => {
    if (profile) {
      form.reset({
        firstName: profile.firstName,
        lastName: profile.lastName,
        title: profile.title,
        bio: profile.bio,
        email: profile.email,
        phone: profile.phone || "",
        location: profile.location || "",
        skills: profile.skills || [],
        socialLinks: profile.socialLinks || [],
      });
    }
  });

  const updateMutation = useMutation({
    mutationFn: async (data: AdminFormData) => {
      const formData = new FormData();
      
      Object.entries(data).forEach(([key, value]) => {
        if (key === 'skills' && Array.isArray(value)) {
          formData.append(key, value.join(', '));
        } else if (key === 'socialLinks' && Array.isArray(value)) {
          formData.append(key, value.join(', '));
        } else if (value !== undefined && value !== null && key !== 'profileImageFile' && key !== 'heroImageFile') {
          formData.append(key, value.toString());
        }
      });
      
      if (profileImageFile) {
        formData.append('profileImage', profileImageFile);
      }
      if (heroImageFile) {
        formData.append('heroImage', heroImageFile);
      }

      const response = await fetch('/api/admin/profile', {
        method: 'PUT',
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Failed to update admin profile');
      }

      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/profile'] });
      toast({
        title: "Success!",
        description: "Profile updated successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update profile",
        variant: "destructive",
      });
    },
  });

  const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>, type: 'profile' | 'hero') => {
    const file = event.target.files?.[0];
    if (file) {
      if (type === 'profile') {
        setProfileImageFile(file);
        const reader = new FileReader();
        reader.onload = (e) => setProfileImagePreview(e.target?.result as string);
        reader.readAsDataURL(file);
      } else {
        setHeroImageFile(file);
        const reader = new FileReader();
        reader.onload = (e) => setHeroImagePreview(e.target?.result as string);
        reader.readAsDataURL(file);
      }
    }
  };

  const removeImage = (type: 'profile' | 'hero') => {
    if (type === 'profile') {
      setProfileImageFile(null);
      setProfileImagePreview(null);
      const fileInput = document.getElementById('profileImage') as HTMLInputElement;
      if (fileInput) fileInput.value = '';
    } else {
      setHeroImageFile(null);
      setHeroImagePreview(null);
      const fileInput = document.getElementById('heroImage') as HTMLInputElement;
      if (fileInput) fileInput.value = '';
    }
  };

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  const onSubmit = (data: AdminFormData) => {
    updateMutation.mutate(data);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading admin profile...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="mb-8">
          <Link href="/">
            <Button variant="outline" className="mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Portfolio
            </Button>
          </Link>
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-3xl font-bold text-secondary">Admin Profile Settings</h1>
              <p className="text-gray-600 mt-2">Update your personal information and portfolio details</p>
            </div>
            <Button variant="outline" onClick={handleLogout} className="ml-4">
              <ArrowLeft className="w-4 h-4 mr-2 rotate-180" />
              Logout
            </Button>
          </div>
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
            {/* Basic Information */}
            <Card>
              <CardHeader>
                <CardTitle>Basic Information</CardTitle>
                <CardDescription>Your personal details and professional information</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="firstName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>First Name</FormLabel>
                        <FormControl>
                          <Input placeholder="John" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="lastName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Last Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Doe" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Professional Title</FormLabel>
                      <FormControl>
                        <Input placeholder="Creative Professional" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="bio"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Bio</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Tell visitors about yourself..." 
                          className="resize-none" 
                          rows={4}
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>

            {/* Contact Information */}
            <Card>
              <CardHeader>
                <CardTitle>Contact Information</CardTitle>
                <CardDescription>How visitors can reach you</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email Address</FormLabel>
                        <FormControl>
                          <Input type="email" placeholder="john.doe@example.com" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Phone Number</FormLabel>
                        <FormControl>
                          <Input placeholder="+1 (555) 123-4567" {...field} value={field.value || ""} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="location"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Location</FormLabel>
                      <FormControl>
                        <Input placeholder="San Francisco, CA" {...field} value={field.value || ""} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>

            {/* Skills and Social Links */}
            <Card>
              <CardHeader>
                <CardTitle>Skills & Social Media</CardTitle>
                <CardDescription>Your technical skills and social media profiles</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <FormField
                  control={form.control}
                  name="skills"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Skills</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="React, Node.js, TypeScript, UI/UX Design (separate with commas)" 
                          onChange={(e) => {
                            const skills = e.target.value.split(',').map(skill => skill.trim()).filter(skill => skill);
                            field.onChange(skills);
                          }}
                          defaultValue={field.value?.join(', ') || ''}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="socialLinks"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Social Media Links</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="https://linkedin.com/in/username, https://github.com/username (separate with commas)" 
                          onChange={(e) => {
                            const links = e.target.value.split(',').map(link => link.trim()).filter(link => link);
                            field.onChange(links);
                          }}
                          defaultValue={field.value?.join(', ') || ''}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>

            {/* Images */}
            <Card>
              <CardHeader>
                <CardTitle>Profile Images</CardTitle>
                <CardDescription>Upload your profile and hero section images</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Profile Image */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Profile Image</label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-primary transition-colors duration-200">
                    {!profileImagePreview && !profile?.profileImage ? (
                      <div className="cursor-pointer" onClick={() => document.getElementById('profileImage')?.click()}>
                        <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                        <p className="text-lg font-medium text-gray-600">Upload Profile Image</p>
                        <p className="text-sm text-gray-500 mt-2">Supports: JPG, PNG, GIF (max 5MB)</p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <img 
                          src={profileImagePreview || profile?.profileImage || ''} 
                          alt="Profile preview" 
                          className="w-32 h-32 object-cover rounded-full mx-auto" 
                        />
                        <div className="flex justify-center space-x-4">
                          <Button 
                            type="button" 
                            variant="outline" 
                            onClick={() => document.getElementById('profileImage')?.click()}
                          >
                            <Upload className="w-4 h-4 mr-2" />
                            Change Image
                          </Button>
                          <Button 
                            type="button" 
                            variant="outline" 
                            onClick={() => removeImage('profile')}
                          >
                            <Trash2 className="w-4 h-4 mr-2" />
                            Remove
                          </Button>
                        </div>
                      </div>
                    )}
                    <input 
                      type="file" 
                      id="profileImage" 
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => handleImageChange(e, 'profile')}
                    />
                  </div>
                </div>

                {/* Hero Image */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Hero Section Image</label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-primary transition-colors duration-200">
                    {!heroImagePreview && !profile?.heroImage ? (
                      <div className="cursor-pointer" onClick={() => document.getElementById('heroImage')?.click()}>
                        <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                        <p className="text-lg font-medium text-gray-600">Upload Hero Image</p>
                        <p className="text-sm text-gray-500 mt-2">Supports: JPG, PNG, GIF (max 5MB)</p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <img 
                          src={heroImagePreview || profile?.heroImage || ''} 
                          alt="Hero preview" 
                          className="w-full max-w-md h-48 object-cover rounded-lg mx-auto" 
                        />
                        <div className="flex justify-center space-x-4">
                          <Button 
                            type="button" 
                            variant="outline" 
                            onClick={() => document.getElementById('heroImage')?.click()}
                          >
                            <Upload className="w-4 h-4 mr-2" />
                            Change Image
                          </Button>
                          <Button 
                            type="button" 
                            variant="outline" 
                            onClick={() => removeImage('hero')}
                          >
                            <Trash2 className="w-4 h-4 mr-2" />
                            Remove
                          </Button>
                        </div>
                      </div>
                    )}
                    <input 
                      type="file" 
                      id="heroImage" 
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => handleImageChange(e, 'hero')}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Save Button */}
            <div className="flex justify-end">
              <Button 
                type="submit" 
                disabled={updateMutation.isPending}
                className="bg-primary text-white hover:bg-blue-700 px-8 py-2"
              >
                {updateMutation.isPending ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4 mr-2" />
                    Save Changes
                  </>
                )}
              </Button>
            </div>
          </form>
        </Form>
      </div>
    </div>
  );
}