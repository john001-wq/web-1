# Portfolio Website

## Overview

This is a modern portfolio website built with React and Express.js, featuring a clean design system using Shadcn/UI components and Tailwind CSS. The application allows users to showcase their work through a portfolio section, provide information about their services, and enable contact functionality. It includes a comprehensive admin interface for managing both portfolio items and personal profile information, with full image upload capabilities for profile pictures and hero section images.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development
- **Routing**: Wouter for lightweight client-side routing
- **UI Components**: Shadcn/UI component library built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS custom properties for theming
- **State Management**: TanStack Query (React Query) for server state management
- **Form Handling**: React Hook Form with Zod validation for type-safe forms
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API structure with proper error handling middleware
- **File Upload**: Multer middleware for handling image uploads with validation
- **Development**: Hot module replacement via Vite integration in development mode

### Data Storage Solutions
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Connection**: Neon Database serverless PostgreSQL for cloud hosting
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Admin Profile Storage**: Dynamic personal information management with default seeded data
- **File Storage**: Local file system storage for uploaded images including profile and hero images
- **Sample Data**: Automatic initialization of sample portfolio items and admin profile

### Authentication and Authorization
- **Authentication Provider**: Replit OpenID Connect (OIDC) integration
- **Session Management**: Express sessions with PostgreSQL store (connect-pg-simple) 
- **Admin Protection**: All admin routes require authentication via isAuthenticated middleware
- **User Management**: Automatic user creation/updating from OIDC claims
- **Frontend Auth**: React hooks for authentication state and unauthorized error handling
- **Security**: Input validation using Zod schemas, secure session cookies, proper logout flow

### External Service Integrations
- **Image Hosting**: Local file upload system with plans for cloud storage
- **Placeholder Images**: Unsplash integration for demo portfolio items
- **Development Tools**: Replit-specific plugins for cloud development environment

### Design System
- **Component Library**: Comprehensive UI component system with consistent styling
- **Theme System**: CSS custom properties supporting light/dark mode theming  
- **Typography**: Responsive typography scale with proper accessibility
- **Color Palette**: Semantic color system with primary, secondary, and accent colors
- **Animation**: Smooth transitions and hover effects throughout the interface

### API Structure
- **Portfolio Management**: CRUD operations for portfolio items with image upload
- **Contact System**: Form submission and storage for client inquiries
- **Admin Profile Management**: CRUD operations for admin personal information with image upload
- **File Serving**: Static file serving for uploaded images with CORS headers
- **Error Handling**: Centralized error handling with proper HTTP status codes

### Development Experience
- **Hot Reload**: Vite dev server with React Fast Refresh
- **Type Safety**: Full TypeScript coverage across frontend, backend, and shared schemas
- **Code Quality**: ESLint and TypeScript strict mode for code quality
- **Build Process**: Optimized production builds with code splitting and asset optimization